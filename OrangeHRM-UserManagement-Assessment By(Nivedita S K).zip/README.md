# OrangeHRM User Management Automation

Automation scripts for the **User Management module** in OrangeHRM using Playwright (JavaScript).

## Project Setup

1. Clone the repository:

```bash
git clone <your-github-repo-link>
cd OrangeHRM-UserManagement
```

2. Install dependencies:

```bash
npm install
npx playwright install
```

## How to Run Test Cases

```bash
npm test
```

The browser will open and execute all scenarios:  
- Login  
- Add user  
- Search user  
- Edit user  
- Validate updates  
- Delete user  

## Playwright Version Used

```bash
npm list playwright
```

Currently using **Playwright 1.45.0**.
