const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Login
  await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
  await page.fill('input[name="username"]', 'Admin');
  await page.fill('input[name="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(3000);

  // Navigate to Admin Module
  await page.click('a[href="/web/index.php/admin/viewAdminModule"]');
  await page.waitForTimeout(2000);

  // Add New User
  await page.click('button:has-text("Add")');
  await page.selectOption('select[name="userRole"]', '1');
  await page.fill('input[name="employeeName"]', 'Paul Collings'); 
  await page.fill('input[name="username"]', 'testuser123');
  await page.selectOption('select[name="status"]', '1');
  await page.fill('input[name="password"]', 'Password123!');
  await page.fill('input[name="confirmPassword"]', 'Password123!');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(2000);

  // Search Newly Created User
  await page.fill('input[placeholder="Username"]', 'testuser123');
  await page.click('button:has-text("Search")');
  await page.waitForTimeout(2000);

  // Edit User
  await page.click('button[title="Edit"]'); 
  await page.selectOption('select[name="status"]', '0');
  await page.fill('input[name="password"]', 'NewPass123!');
  await page.fill('input[name="confirmPassword"]', 'NewPass123!');
  await page.click('button[type="submit"]');
  await page.waitForTimeout(2000);

  // Validate Updated Details
  await page.fill('input[placeholder="Username"]', 'testuser123');
  await page.click('button:has-text("Search")');
  await page.waitForTimeout(2000);

  // Delete User
  await page.check('input[type="checkbox"]'); 
  await page.click('button:has-text("Delete")');
  await page.click('button:has-text("Yes, Delete")');
  await page.waitForTimeout(2000);

  console.log("User Management E2E test completed.");

  await browser.close();
})();